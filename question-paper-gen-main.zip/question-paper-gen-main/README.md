# QpGen Setup

## Prerequisites
- Install Node.js (LTS)
- Install MongoDB Community Server locally and make sure the MongoDB service is running
  - Docs: https://www.mongodb.com/docs/manual/installation/

## Environment Variables
Create your own env file by copying the example and editing values as needed:

```
cp Server/.env.example Server/.env
```

Then open `Server/.env` and set your values. Example:

```
MONGO_URI=mongodb://localhost:27017/mydatabase
PORT=5000
JWT_SECRET=your_jwt_secret_key
```

Notes:
- `MONGO_URI` is used by the server to connect to MongoDB via `process.env.MONGO_URI`.
- `PORT` is optional (defaults to 5000).
- `JWT_SECRET` is required for auth features—set a strong value in production.

If `MONGO_URI` is not set, the server will fall back to `mongodb://localhost:27017/mydatabase` and log a warning. Ensure MongoDB is running locally.

## Install Dependencies
From the root of the project:

```
# Client (React app)
cd client
npm install

# Server (Express API)
cd ../Server
npm install
```

## Run the Server
From the `Server/` directory:

```
node server.js
```

If you prefer hot-reload during development, install nodemon globally or add a script in `Server/package.json` like:

```
"scripts": {
  "dev": "nodemon server.js"
}
```

Then run:

```
npm run dev
```

## Run the Client
From the `client/` directory:

```
npm start
```

## Summary of Changes
- MongoDB connection in `Server/server.js` now uses `dotenv` and `process.env.MONGO_URI`.
- `.env` example provided; `.env` files are ignored by Git via root `.gitignore`.
- README updated with setup instructions and local MongoDB requirement.
