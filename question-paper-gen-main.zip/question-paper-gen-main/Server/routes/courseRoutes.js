const express = require('express');
const multer = require('multer');
const { defineCourse, getCourses } = require('../controllers/courseController');
const auth = require('../middleware/auth');

const router = express.Router();
const upload = multer();

router.post('/define-course', auth, upload.any(), defineCourse);
router.get('/courses', auth, getCourses);

module.exports = router;