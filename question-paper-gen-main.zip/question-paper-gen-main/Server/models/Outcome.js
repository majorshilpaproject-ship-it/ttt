const mongoose = require('mongoose');

const OutcomeSchema = new mongoose.Schema({
  course: {
    type: String,
    required: true
  },
  program: {
    type: String,
    required: true
  },
  code: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Outcome', OutcomeSchema);