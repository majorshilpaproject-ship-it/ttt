const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const dotenv = require('dotenv');
const path = require('path');
const fs = require('fs');

// Load environment variables
dotenv.config();

// Initialize Express
const app = express();

// CORS configuration
app.use(cors({
  origin: [
    'http://localhost:3000',
    'http://localhost:3001',
    'http://localhost:3005',
    'http://192.168.1.24:3001'
  ],
  credentials: true
}));

// Middleware
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Create uploads directory if it doesn't exist
const uploadsDir = path.join(__dirname, 'uploads');
const materialUploadsDir = path.join(uploadsDir, 'materials');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir);
}
if (!fs.existsSync(materialUploadsDir)) {
  fs.mkdirSync(materialUploadsDir);
}

// Serve static files from uploads directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Ensure MongoDB connection
const mongoUri = process.env.MONGO_URI || 'mongodb://localhost:27017/mydatabase';
if (!process.env.MONGO_URI) {
  console.warn('MONGO_URI not set. Falling back to default: mongodb://localhost:27017/mydatabase');
}

mongoose.connect(mongoUri, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected successfully'))
.catch(err => console.error('MongoDB connection error:', err));

// Import Routes
const authRoutes = require('./routes/auth');
const materialRoutes = require('./routes/materials');
const outcomeRoutes = require('./routes/outcomes');
const questionRoutes = require('./routes/questions');
const courseRoutes = require('./routes/courseRoutes'); // Import course routes

// Use Routes
app.use('/api/auth', authRoutes);
app.use('/api/materials', materialRoutes);
app.use('/api/outcomes', outcomeRoutes);
app.use('/api/questions', questionRoutes);
app.use('/api/courses', courseRoutes); // Use course routes

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ 
    message: 'Something went wrong!',
    error: err.message 
  });
});

// Start server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  console.log(`File uploads directory: ${uploadsDir}`);
});