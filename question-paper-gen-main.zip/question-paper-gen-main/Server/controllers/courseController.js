const Course = require('../models/Course');

// Create a new course
exports.defineCourse = async (req, res) => {
  try {
    console.log('Received course data:', req.body);

    // Parse the outcomes and coPoMapping
    let outcomes, coPoMapping;
    try {
      outcomes = JSON.parse(req.body.outcomes);
      coPoMapping = JSON.parse(req.body.coPoMapping);
    } catch (err) {
      return res.status(400).json({ 
        message: 'Invalid data format',
        error: err.message 
      });
    }

    // Create and save the course
    const course = new Course({
      name: req.body.name,
      description: req.body.description,
      outcomes: outcomes,
      coPoMapping: coPoMapping,
      createdBy: req.userId
    });

    const savedCourse = await course.save();
    console.log('Course saved successfully:', savedCourse);

    res.status(201).json({
      message: 'Course created successfully',
      course: savedCourse
    });
  } catch (error) {
    console.error('Error creating course:', error);
    res.status(500).json({
      message: 'Failed to create course',
      error: error.message
    });
  }
};

// Get all courses for the current user
exports.getCourses = async (req, res) => {
  try {
    console.log('Fetching user courses...');
    const courses = await Course.find({ createdBy: req.userId }).sort({ createdAt: -1 });
    console.log(`Found ${courses.length} courses for user`);
    res.json(courses);
  } catch (error) {
    console.error('Error fetching courses:', error);
    res.status(500).json({ 
      message: 'Error fetching courses', 
      error: error.message 
    });
  }
};