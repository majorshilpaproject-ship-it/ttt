import React, { useState } from 'react';
import { Formik, Form } from 'formik';
import * as Yup from 'yup';
import {
  Container,
  Typography,
  TextField,
  Button,
  Grid,
  Paper,
  Alert,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Select,
  MenuItem,
} from '@mui/material';
import axios from 'axios';

const validationSchema = Yup.object({
  name: Yup.string().required('Course name is required'),
  description: Yup.string(),
  outcomes: Yup.array()
    .of(Yup.string())
    .min(1, 'At least one outcome is required'),
});

const DefineCourse = () => {
  const [status, setStatus] = useState(null);
  const [files, setFiles] = useState([]);
  const poHeaders = ['PO1', 'PO2', 'PO3', 'PO4', 'PO5', 'PO6', 'PO7', 'PO8'];
  const mappingScale = [1, 2, 3];

  const handleFileChange = (e) => {
    setFiles(e.target.files);
  };

  return (
    <Container maxWidth="md">
      <Paper elevation={3} sx={{ p: 4, mt: 5 }}>
        <Typography variant="h5" gutterBottom>
          Define a New Course
        </Typography>

        {status === 'success' && (
          <Alert severity="success" sx={{ mb: 2 }}>
            Course defined successfully!
          </Alert>
        )}
        {status === 'error' && (
          <Alert severity="error" sx={{ mb: 2 }}>
            Failed to create course. Please try again.
          </Alert>
        )}

        <Formik
          initialValues={{
            name: '',
            description: '',
            outcomes: ['', '', '', '', ''],
            coPoMapping: {}
          }}
          validationSchema={validationSchema}
          onSubmit={async (values, { setSubmitting, resetForm }) => {
            try {
              setStatus(null);
              const formData = new FormData();
              
              // Add basic course data
              formData.append('name', values.name);
              formData.append('description', values.description);
              
              // Filter out empty outcomes and add to formData
              const filteredOutcomes = values.outcomes.filter(outcome => outcome.trim() !== '');
              formData.append('outcomes', JSON.stringify(filteredOutcomes));
              
              // Add CO-PO mapping
              formData.append('coPoMapping', JSON.stringify(values.coPoMapping));

              // Add any files
              for (const file of files) {
                formData.append('materials', file);
              }

              console.log('Submitting course data:', {
                name: values.name,
                description: values.description,
                outcomes: filteredOutcomes,
                coPoMapping: values.coPoMapping
              });

              const response = await axios.post('http://localhost:5000/api/courses/define-course', formData, {
                headers: {
                  'Content-Type': 'multipart/form-data'
                }
              });

              console.log('Course created:', response.data);
              setStatus('success');
              resetForm();
              setFiles([]);
            } catch (error) {
              console.error('Course creation error:', error);
              setStatus('error');
            } finally {
              setSubmitting(false);
            }
          }}
        >
          {({ values, errors, touched, handleChange, setFieldValue, isSubmitting }) => (
            <Form>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    label="Course Name"
                    name="name"
                    value={values.name}
                    onChange={handleChange}
                    error={touched.name && Boolean(errors.name)}
                    helperText={touched.name && errors.name}
                  />
                </Grid>
                <Grid item xs={12}>
                  <TextField
                    fullWidth
                    multiline
                    rows={4}
                    label="Description (optional)"
                    name="description"
                    value={values.description}
                    onChange={handleChange}
                  />
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    Course Outcomes
                  </Typography>
                  <Grid container spacing={2}>
                    {values.outcomes.map((outcome, index) => (
                      <Grid item xs={12} key={index}>
                        <TextField
                          fullWidth
                          label={`Outcome ${index + 1}`}
                          value={outcome}
                          onChange={(e) => {
                            const updated = [...values.outcomes];
                            updated[index] = e.target.value;
                            setFieldValue('outcomes', updated);
                          }}
                          error={touched.outcomes && Boolean(errors.outcomes?.[index])}
                          helperText={touched.outcomes && errors.outcomes?.[index]}
                        />
                      </Grid>
                    ))}
                  </Grid>
                </Grid>
                <Grid item xs={12}>
                  <Typography variant="h6" gutterBottom>
                    CO-PO Mapping
                  </Typography>
                  <TableContainer component={Paper}>
                    <Table>
                      <TableHead>
                        <TableRow>
                          <TableCell>Outcomes</TableCell>
                          {poHeaders.map((header) => (
                            <TableCell key={header} align="center">
                              {header}
                            </TableCell>
                          ))}
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {values.outcomes.map((outcome, index) => (
                          <TableRow key={`row-${index}`}>
                            <TableCell>{`CO${index + 1}`}</TableCell>
                            {poHeaders.map((po) => (
                              <TableCell key={`${outcome}-${po}`} align="center">
                                <Select
                                  value={values.coPoMapping[`CO${index + 1}`]?.[po] || ''}
                                  onChange={(e) => {
                                    const updatedMapping = { ...values.coPoMapping };
                                    if (!updatedMapping[`CO${index + 1}`]) {
                                      updatedMapping[`CO${index + 1}`] = {};
                                    }
                                    updatedMapping[`CO${index + 1}`][po] = e.target.value;
                                    setFieldValue('coPoMapping', updatedMapping);
                                  }}
                                  displayEmpty
                                  fullWidth
                                  size="small"
                                >
                                  <MenuItem value="">-</MenuItem>
                                  {mappingScale.map((scale) => (
                                    <MenuItem key={scale} value={scale}>
                                      {scale}
                                    </MenuItem>
                                  ))}
                                </Select>
                              </TableCell>
                            ))}
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                  <Typography variant="body2" sx={{ mt: 2 }}>
                    <strong>Mapping Scale:</strong> 1 - Low correlation | 2 - Medium correlation | 3 - High correlation
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Button
                    variant="outlined"
                    component="label"
                    fullWidth
                  >
                    Upload Study Materials
                    <input
                      type="file"
                      hidden
                      multiple
                      onChange={handleFileChange}
                      accept=".pdf"
                    />
                  </Button>
                  {files.length > 0 && (
                    <Typography variant="body2" sx={{ mt: 1 }}>
                      {files.length} file(s) selected
                    </Typography>
                  )}
                </Grid>
                <Grid item xs={12}>
                  <Button
                    variant="contained"
                    color="primary"
                    type="submit"
                    disabled={isSubmitting}
                    fullWidth
                  >
                    {isSubmitting ? 'Submitting...' : 'Define Course'}
                  </Button>
                </Grid>
              </Grid>
            </Form>
          )}
        </Formik>
      </Paper>

      {/* View Courses Section */}
      <Paper elevation={2} sx={{ p: 3, mt: 4 }}>
        <Typography variant="h6" gutterBottom>
          View Courses
        </Typography>
        {/* The view courses section can remain as it is, or be modified as needed */}
      </Paper>
    </Container>
  );
};

export default DefineCourse;